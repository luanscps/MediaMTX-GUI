package com.mediamtx.manager.panels;

import com.mediamtx.manager.AppWindow;
import com.mediamtx.manager.service.MediaMTXService;
import com.mediamtx.manager.theme.Theme;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class SourcesPanel extends JPanel {

    private static final String API_PATHS = "http://localhost:9997/v3/paths/list";

    private final MediaMTXService service;
    private DefaultTableModel tableModel;
    private JLabel statusLabel;
    private Timer autoRefreshTimer;

    // Colunas da tabela
    private static final String[] COLS = {
        "Path / Nome", "Tipo de Fonte", "URL / Source", "Estado", "Leitores"
    };

    public SourcesPanel(MediaMTXService service) {
        this.service = service;
        setLayout(new BorderLayout(12, 12));
        setBackground(Theme.BG);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(buildHeader(),  BorderLayout.NORTH);
        add(buildTable(),   BorderLayout.CENTER);
        add(buildFooter(),  BorderLayout.SOUTH);

        // Auto-refresh a cada 5 segundos
        autoRefreshTimer = new Timer(5000, e -> refreshPaths());
        autoRefreshTimer.start();

        // Carga inicial
        refreshPaths();
    }

    // -------------------------------------------------------------------------
    // Header com título e botões
    // -------------------------------------------------------------------------
    private JPanel buildHeader() {
        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.setBackground(Theme.BG);
        top.setBorder(new EmptyBorder(0, 0, 12, 0));

        JLabel title = new JLabel("\uD83D\uDCF9  Fontes de Retransmissão (Sources)");
        title.setFont(Theme.FONT_TITLE);
        title.setForeground(Theme.ACCENT);
        top.add(title, BorderLayout.WEST);

        // Painel de botões
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btns.setBackground(Theme.BG);

        statusLabel = new JLabel("●  aguardando...");
        statusLabel.setFont(Theme.FONT_SMALL);
        statusLabel.setForeground(Theme.TEXT_DIM);
        btns.add(statusLabel);

        JButton btnAdd = makeButton("➕ Adicionar Fonte", new Color(14, 165, 233));
        btnAdd.addActionListener(e -> openAddSourceDialog());
        btns.add(btnAdd);

        JButton btnRefresh = makeButton("↺ Atualizar", new Color(100, 116, 139));
        btnRefresh.addActionListener(e -> refreshPaths());
        btns.add(btnRefresh);

        top.add(btns, BorderLayout.EAST);
        return top;
    }

    // -------------------------------------------------------------------------
    // Tabela dinâmica
    // -------------------------------------------------------------------------
    private JScrollPane buildTable() {
        tableModel = new DefaultTableModel(COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable table = new JTable(tableModel);
        table.setFont(Theme.FONT_MEDIUM);
        table.setForeground(Theme.TEXT);
        table.setBackground(Theme.BG_CARD);
        table.setGridColor(Theme.BORDER);
        table.setRowHeight(32);
        table.setSelectionBackground(new Color(14, 165, 233, 40));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.getTableHeader().setFont(Theme.FONT_BOLD);
        table.getTableHeader().setBackground(new Color(30, 41, 59));
        table.getTableHeader().setForeground(Theme.TEXT_DIM);

        // Renderer com cores por estado e linhas alternadas
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                String val = v == null ? "" : v.toString();

                if (c == 3) { // coluna Estado
                    if (val.equalsIgnoreCase("ready")) {
                        setForeground(new Color(34, 197, 94));
                        setText("● ready");
                    } else if (val.equalsIgnoreCase("waiting")) {
                        setForeground(new Color(234, 179, 8));
                        setText("◌ waiting");
                    } else {
                        setForeground(new Color(239, 68, 68));
                        setText("✕ " + val);
                    }
                } else {
                    setForeground(Theme.TEXT);
                    setText(val);
                }

                setBackground(sel ? new Color(14, 165, 233, 40)
                    : (r % 2 == 0 ? Theme.BG_CARD : new Color(22, 30, 46)));
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        });

        // Larguras das colunas
        TableColumnModel cm = table.getColumnModel();
        cm.getColumn(0).setPreferredWidth(140);
        cm.getColumn(1).setPreferredWidth(150);
        cm.getColumn(2).setPreferredWidth(320);
        cm.getColumn(3).setPreferredWidth(100);
        cm.getColumn(4).setPreferredWidth(80);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(Theme.BORDER_MED));
        scroll.getViewport().setBackground(Theme.BG_CARD);
        return scroll;
    }

    // -------------------------------------------------------------------------
    // Rodapé informativo
    // -------------------------------------------------------------------------
    private JLabel buildFooter() {
        JLabel info = new JLabel(
            "<html>Atualização automática a cada <b>5s</b> via API REST (<code>GET /v3/paths/list</code>). " +
            "Use <b>➕ Adicionar Fonte</b> para inserir um novo path no <b>mediamtx.yml</b>. " +
            "Para câmeras Android com <b>CAMSTREAMER-BR</b>, use fonte <code>rtsp://IP:8554/live</code>.</html>"
        );
        info.setFont(Theme.FONT_SMALL);
        info.setForeground(Theme.TEXT_DIM);
        info.setBorder(new EmptyBorder(10, 0, 0, 0));
        return info;
    }

    // -------------------------------------------------------------------------
    // Refresh via API REST do MediaMTX
    // -------------------------------------------------------------------------
    private void refreshPaths() {
        if (!service.isRunning()) {
            SwingUtilities.invokeLater(() -> {
                tableModel.setRowCount(0);
                statusLabel.setText("●  servidor parado");
                statusLabel.setForeground(new Color(239, 68, 68));
            });
            return;
        }

        // Roda em thread separada para não travar a UI
        new Thread(() -> {
            try {
                String json = httpGet(API_PATHS);
                List<Object[]> rows = parsePaths(json);
                SwingUtilities.invokeLater(() -> {
                    tableModel.setRowCount(0);
                    for (Object[] row : rows) tableModel.addRow(row);
                    statusLabel.setText("●  " + rows.size() + " path(s) ativos");
                    statusLabel.setForeground(new Color(34, 197, 94));
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    statusLabel.setText("●  API indisponível");
                    statusLabel.setForeground(new Color(234, 179, 8));
                });
            }
        }, "sources-refresh").start();
    }

    // -------------------------------------------------------------------------
    // HTTP GET simples (sem dependência externa)
    // -------------------------------------------------------------------------
    private String httpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(2000);
        conn.setReadTimeout(3000);
        conn.setRequestProperty("Accept", "application/json");

        try (InputStream is = conn.getInputStream();
             BufferedReader br = new BufferedReader(
                     new InputStreamReader(is, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    // -------------------------------------------------------------------------
    // Parser JSON manual (sem biblioteca externa)
    // Formato esperado: {"items":[{"name":"...","ready":true,"source":{...},...}]}
    // -------------------------------------------------------------------------
    private List<Object[]> parsePaths(String json) {
        List<Object[]> rows = new ArrayList<>();
        // Extrai cada bloco {...} dentro de "items":[...]
        int itemsIdx = json.indexOf("\"items\"");
        if (itemsIdx < 0) return rows;

        int arrStart = json.indexOf('[', itemsIdx);
        int arrEnd   = json.lastIndexOf(']');
        if (arrStart < 0 || arrEnd < 0) return rows;

        String arr = json.substring(arrStart + 1, arrEnd);
        // Divide em objetos de path pelo nível de chaves
        List<String> objects = splitTopLevelObjects(arr);

        for (String obj : objects) {
            String name      = extractString(obj, "name");
            boolean ready    = obj.contains("\"ready\":true");
            String state     = ready ? "ready" : "waiting";

            // Source: pode ser objeto ou string
            String sourceUrl  = extractSourceUrl(obj);
            String sourceType = detectSourceType(obj, sourceUrl);

            // Readers: conta ocorrências de "type" dentro de "readers"
            int readers = countReaders(obj);

            rows.add(new Object[]{ name, sourceType, sourceUrl, state, readers });
        }
        return rows;
    }

    private List<String> splitTopLevelObjects(String arr) {
        List<String> list = new ArrayList<>();
        int depth = 0, start = -1;
        for (int i = 0; i < arr.length(); i++) {
            char ch = arr.charAt(i);
            if (ch == '{') { if (depth == 0) start = i; depth++; }
            else if (ch == '}') {
                depth--;
                if (depth == 0 && start >= 0) {
                    list.add(arr.substring(start, i + 1));
                    start = -1;
                }
            }
        }
        return list;
    }

    private String extractString(String obj, String key) {
        String search = "\"" + key + "\":\"";
        int idx = obj.indexOf(search);
        if (idx < 0) return "";
        int start = idx + search.length();
        int end = obj.indexOf('"', start);
        return end < 0 ? "" : obj.substring(start, end);
    }

    private String extractSourceUrl(String obj) {
        // Tenta pegar "source":{"type":"...","id":"..."}
        // Verifica se tem URL direta no campo source
        int srcIdx = obj.indexOf("\"source\":");
        if (srcIdx < 0) return "(publisher direto)";
        String after = obj.substring(srcIdx + 9).trim();
        if (after.startsWith("\"")) {
            // source é uma string
            int end = after.indexOf('"', 1);
            return end > 0 ? after.substring(1, end) : "(publisher direto)";
        }
        if (after.startsWith("{")) {
            // source é objeto: extrai "id" se houver URL
            String type = extractString(after, "type");
            String id   = extractString(after, "id");
            if (!id.isEmpty()) return type + " / " + id;
            return type.isEmpty() ? "(publisher direto)" : type;
        }
        return "(publisher direto)";
    }

    private String detectSourceType(String obj, String sourceUrl) {
        String lower = sourceUrl.toLowerCase();
        if (lower.startsWith("rtsp://"))  return "RTSP pull";
        if (lower.startsWith("rtmp://"))  return "RTMP pull";
        if (lower.startsWith("srt://"))   return "SRT pull";
        if (obj.contains("rtmpConn"))     return "RTMP push";
        if (obj.contains("rtspSession")) return "RTSP push";
        if (obj.contains("srtConn"))     return "SRT push";
        if (obj.contains("webrtcSession")) return "WebRTC push";
        if (obj.contains("rpiCamera"))   return "RPi Camera";
        return "publisher externo";
    }

    private int countReaders(String obj) {
        int idx = obj.indexOf("\"readers\"");
        if (idx < 0) return 0;
        int count = 0;
        int pos = idx;
        while ((pos = obj.indexOf("\"type\"", pos + 1)) >= 0) {
            // Só conta se ainda dentro do array de readers
            int bracketClose = obj.indexOf(']', idx);
            if (bracketClose > 0 && pos > bracketClose) break;
            count++;
        }
        return count;
    }

    // -------------------------------------------------------------------------
    // Dialog "Adicionar Fonte"
    // -------------------------------------------------------------------------
    private void openAddSourceDialog() {
        JDialog dialog = new JDialog(
            (Frame) SwingUtilities.getWindowAncestor(this),
            "➕ Adicionar Fonte de Retransmissão", true
        );
        dialog.setSize(520, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Theme.BG);
        panel.setBorder(new EmptyBorder(20, 24, 20, 24));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets  = new Insets(6, 4, 6, 4);
        gbc.anchor  = GridBagConstraints.WEST;
        gbc.fill    = GridBagConstraints.HORIZONTAL;

        // Linha 0 — path name
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.3;
        panel.add(label("Nome do Path:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JTextField tfPath = field("ex: cam1");
        panel.add(tfPath, gbc);

        // Linha 1 — tipo
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.3;
        panel.add(label("Tipo de Fonte:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        String[] types = {
            "RTMP push (câmera/OBS → servidor)",
            "RTSP pull (servidor puxa câmera)",
            "SRT push (encoder → servidor)",
            "SRT pull (servidor puxa SRT)",
            "FFmpeg runOnDemand",
            "Câmera Android - CAMSTREAMER-BR"
        };
        JComboBox<String> cbType = new JComboBox<>(types);
        cbType.setFont(Theme.FONT_MEDIUM);
        panel.add(cbType, gbc);

        // Linha 2 — URL / source
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.3;
        JLabel lblUrl = label("URL / Source:");
        panel.add(lblUrl, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JTextField tfUrl = field("rtsp://192.168.1.X:8554/live");
        panel.add(tfUrl, gbc);

        // Linha 3 — IP Android (só para CAMSTREAMER-BR)
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0.3;
        JLabel lblIp = label("IP do Android:");
        panel.add(lblIp, gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JTextField tfIp = field("192.168.1.X");
        panel.add(tfIp, gbc);
        lblIp.setVisible(false); tfIp.setVisible(false);

        // Linha 4 — preview YAML
        gbc.gridx = 0; gbc.gridy = 4; gbc.weightx = 0.3;
        panel.add(label("Preview YAML:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7;
        JTextArea taPreview = new JTextArea(4, 30);
        taPreview.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        taPreview.setBackground(new Color(15, 23, 42));
        taPreview.setForeground(new Color(148, 163, 184));
        taPreview.setEditable(false);
        taPreview.setBorder(new EmptyBorder(6, 8, 6, 8));
        panel.add(new JScrollPane(taPreview), gbc);

        // Atualiza placeholder e preview conforme tipo
        ActionListener updatePreview = e -> {
            int idx = cbType.getSelectedIndex();
            String path = tfPath.getText().trim().isEmpty() ? "meu_path" : tfPath.getText().trim();
            String url  = tfUrl.getText().trim();
            String yaml;
            boolean isAndroid = idx == 5;
            lblIp.setVisible(isAndroid);
            tfIp.setVisible(isAndroid);
            switch (idx) {
                case 0: // RTMP push
                    tfUrl.setEnabled(false);
                    yaml = "paths:\n  " + path + ":\n    # publisher envia via rtmp://HOST:1935/" + path;
                    break;
                case 1: // RTSP pull
                    tfUrl.setEnabled(true);
                    tfUrl.putClientProperty("placeholder", "rtsp://192.168.1.X:554/stream");
                    yaml = "paths:\n  " + path + ":\n    source: " + (url.isEmpty() ? "rtsp://IP:554/stream" : url);
                    break;
                case 2: // SRT push
                    tfUrl.setEnabled(false);
                    yaml = "paths:\n  " + path + ":\n    # publisher envia via srt://HOST:8890?streamid=publish:" + path;
                    break;
                case 3: // SRT pull
                    tfUrl.setEnabled(true);
                    yaml = "paths:\n  " + path + ":\n    source: " + (url.isEmpty() ? "srt://IP:8890?streamid=request:" + path : url);
                    break;
                case 4: // FFmpeg runOnDemand
                    tfUrl.setEnabled(true);
                    tfUrl.putClientProperty("placeholder", "/dev/video0 ou rtsp://...");
                    yaml = "paths:\n  " + path + ":\n    runOnDemand: ffmpeg -i " +
                           (url.isEmpty() ? "/dev/video0" : url) +
                           " -c:v libx264 -preset ultrafast -b:v 1500k -g 30\n" +
                           "               -c:a aac -b:a 128k -f rtsp rtsp://localhost:8554/$MTX_PATH\n" +
                           "    runOnDemandRestart: yes";
                    break;
                case 5: // CAMSTREAMER-BR
                    tfUrl.setEnabled(false);
                    String ip = tfIp.getText().trim().isEmpty() ? "192.168.1.X" : tfIp.getText().trim();
                    yaml = "paths:\n  " + path + ":\n    source: rtsp://" + ip + ":8554/live";
                    break;
                default:
                    yaml = "";
            }
            taPreview.setText(yaml);
            dialog.revalidate();
        };

        cbType.addActionListener(updatePreview);
        tfPath.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { updatePreview.actionPerformed(null); }
        });
        tfUrl.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { updatePreview.actionPerformed(null); }
        });
        tfIp.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { updatePreview.actionPerformed(null); }
        });
        updatePreview.actionPerformed(null);

        // Botões de ação
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Theme.BG);

        // Botão CAMSTREAMER-BR WebControl
        JButton btnWebCtrl = makeButton("🔗 Abrir WebControl Android", new Color(99, 102, 241));
        btnWebCtrl.setVisible(false);
        btnWebCtrl.addActionListener(e -> {
            String ip = tfIp.getText().trim().isEmpty() ? "localhost" : tfIp.getText().trim();
            AppWindow.openBrowser("http://" + ip + ":8080");
        });

        cbType.addActionListener(e -> btnWebCtrl.setVisible(cbType.getSelectedIndex() == 5));

        JButton btnInsert = makeButton("✔ Inserir no YAML", new Color(14, 165, 233));
        btnInsert.addActionListener(e -> {
            String yaml = taPreview.getText().trim();
            if (yaml.isEmpty()) return;
            JOptionPane.showMessageDialog(dialog,
                "<html>Bloco gerado:<br><pre>" + yaml + "</pre><br>" +
                "Cole no final da seção <b>paths:</b> do seu <b>mediamtx.yml</b> " +
                "ou use a aba <b>Config YAML</b> para editar.</html>",
                "YAML gerado", JOptionPane.INFORMATION_MESSAGE);
            dialog.dispose();
        });

        JButton btnCancel = makeButton("Cancelar", new Color(100, 116, 139));
        btnCancel.addActionListener(e -> dialog.dispose());

        btnRow.add(btnWebCtrl);
        btnRow.add(btnCancel);
        btnRow.add(btnInsert);

        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        panel.add(btnRow, gbc);

        dialog.add(panel);
        dialog.setVisible(true);
    }

    // -------------------------------------------------------------------------
    // Helpers de UI
    // -------------------------------------------------------------------------
    private JLabel label(String text) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.FONT_MEDIUM);
        l.setForeground(Theme.TEXT);
        return l;
    }

    private JTextField field(String placeholder) {
        JTextField tf = new JTextField();
        tf.setFont(Theme.FONT_MEDIUM);
        tf.setBackground(new Color(15, 23, 42));
        tf.setForeground(Theme.TEXT);
        tf.setCaretColor(Theme.TEXT);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.BORDER_MED),
            new EmptyBorder(4, 8, 4, 8)
        ));
        tf.putClientProperty("placeholder", placeholder);
        return tf;
    }

    private JButton makeButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(Theme.FONT_MEDIUM);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(6, 14, 6, 14));
        return btn;
    }

    /** Para o timer ao fechar o painel (evita threads orphan). */
    public void stopRefresh() {
        if (autoRefreshTimer != null) autoRefreshTimer.stop();
    }
}