package com.mediamtx.manager;

import com.mediamtx.manager.panels.*;
import com.mediamtx.manager.service.MediaMTXService;
import com.mediamtx.manager.theme.Theme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class AppWindow extends JFrame {

    public static final String VERSION      = "1.0.0";
    public static final String REPO_URL     = "https://github.com/luanscps/MediaMTX-GUI";
    public static final String MEDIAMTX_URL = "https://github.com/bluenviron/mediamtx";
    public static final String AUTHOR       = "Luan Silva";
    public static final String AUTHOR_URL   = "https://github.com/luanscps";

    private final MediaMTXService service = new MediaMTXService();
    private HeaderPanel  headerPanel;
    private LogPanel     logPanel;
    private SidebarPanel sidebarPanel;
    private JTabbedPane  tabbedPane;

    // Referências às abas que precisam de integração entre si
    private ConfigPanel  configPanel;
    private SourcesPanel sourcesPanel;

    // Índices das abas (para navegar via menu)
    private static final int TAB_DASHBOARD = 0;
    private static final int TAB_CONFIG    = 1;
    private static final int TAB_RECORD    = 2;
    private static final int TAB_PATHS     = 3;
    private static final int TAB_SOURCES   = 4;  // ← NOVO

    public AppWindow() {
        setTitle("MediaMTX GUI — v" + VERSION);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(1400, 920);
        setMinimumSize(new Dimension(1100, 720));
        setLocationRelativeTo(null);
        setIconImage(AppIcon.get());

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (service.isRunning()) {
                    int opt = JOptionPane.showConfirmDialog(AppWindow.this,
                        "O servidor MediaMTX está rodando.\nDeseja parar e sair?",
                        "Confirmação", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                    if (opt != JOptionPane.YES_OPTION) return;
                    service.stop();
                }
                // Para o timer de auto-refresh do SourcesPanel antes de fechar
                if (sourcesPanel != null) sourcesPanel.stopRefresh();
                dispose();
                System.exit(0);
            }
        });

        buildMenuBar();
        buildUI();

        service.setLogConsumer(msg -> SwingUtilities.invokeLater(() -> {
            logPanel.append(msg);
            headerPanel.updateStatus(service.isRunning());
            sidebarPanel.updateStatus(service.isRunning());
        }));
    }

    private void buildMenuBar() {
        JMenuBar bar = new JMenuBar();
        bar.setBorder(new EmptyBorder(2, 4, 2, 4));

        // ── Arquivo ──────────────────────────────────────────────────────────
        JMenu mArquivo = menu("Arquivo");
        mArquivo.add(item("Abrir binário...",    e -> service.chooseBinary(this)));
        mArquivo.add(item("Abrir config YML...", e -> service.chooseConfig(this)));
        mArquivo.addSeparator();
        mArquivo.add(item("Sair", e -> dispatchEvent(
            new WindowEvent(this, WindowEvent.WINDOW_CLOSING))));

        // ── Servidor ─────────────────────────────────────────────────────────
        JMenu mServidor = menu("Servidor");
        mServidor.add(item("▶  Iniciar",   e -> service.start()));
        mServidor.add(item("■  Parar",     e -> service.stop()));
        mServidor.add(item("↺  Reiniciar", e -> service.restart()));
        mServidor.addSeparator();
        mServidor.add(item("Abrir API no browser", e -> openBrowser("http://localhost:9997")));
        mServidor.addSeparator();
        // Atalho direto para a aba Sources
        mServidor.add(item("📹  Gerenciar Fontes (Sources)",
            e -> tabbedPane.setSelectedIndex(TAB_SOURCES)));

        // ── Visualizar ───────────────────────────────────────────────────────
        JMenu mView = menu("Visualizar");
        mView.add(item("Limpar log",    e -> logPanel.clear()));
        mView.add(item("Salvar log...", e -> logPanel.saveToFile(this)));

        // ── Ajuda ────────────────────────────────────────────────────────────
        JMenu mAjuda = menu("Ajuda");
        mAjuda.add(item("Documentação MediaMTX",    e -> openBrowser(MEDIAMTX_URL)));
        mAjuda.add(item("Repositório MediaMTX-GUI", e -> openBrowser(REPO_URL)));
        mAjuda.addSeparator();
        mAjuda.add(item("Sobre", e -> showAbout()));

        bar.add(mArquivo);
        bar.add(mServidor);
        bar.add(mView);
        bar.add(mAjuda);
        setJMenuBar(bar);
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.BG);

        headerPanel  = new HeaderPanel(service, this);
        root.add(headerPanel, BorderLayout.NORTH);

        sidebarPanel = new SidebarPanel(service, this);
        root.add(sidebarPanel, BorderLayout.WEST);

        tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setFont(Theme.FONT_MEDIUM);

        // Instancia painéis que precisam de referência cruzada
        configPanel  = new ConfigPanel(service);
        sourcesPanel = new SourcesPanel(service, this);  // passa AppWindow

        tabbedPane.addTab("  Dashboard  ", new DashboardPanel(service)); // 0
        tabbedPane.addTab("  Config YAML  ", configPanel);               // 1
        tabbedPane.addTab("  Gravação  ",    new RecordPanel(service));  // 2
        tabbedPane.addTab("  Paths  ",       new PathsPanel(service));   // 3
        tabbedPane.addTab("  Sources  ",     sourcesPanel);              // 4 ← NOVO

        root.add(tabbedPane, BorderLayout.CENTER);

        logPanel = new LogPanel();
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, root, logPanel);
        split.setResizeWeight(0.76);
        split.setDividerSize(6);
        split.setBorder(null);
        logPanel.setMinimumSize(new Dimension(0, 200));
        add(split);
    }

    /**
     * Chamado pelo SourcesPanel/AddSourceDialog ao clicar "Inserir no YAML".
     * Injeta o bloco no ConfigPanel e navega para a aba Config YAML.
     */
    public void insertYamlAndNavigate(String yamlBlock) {
        configPanel.appendYaml(yamlBlock);
        tabbedPane.setSelectedIndex(TAB_CONFIG);
    }

    private void showAbout() {
        String html = "<html><body style='font-family:sans-serif;padding:10px;width:360px'>"
            + "<h2 style='color:#0ea5e9;margin:0 0 6px 0'>MediaMTX GUI</h2>"
            + "<p style='margin:4px 0'>Versão: <b>" + VERSION + "</b></p>"
            + "<p style='margin:4px 0'>Interface gráfica profissional para gerenciar o servidor <b>MediaMTX</b>.</p>"
            + "<hr>"
            + "<p style='margin:6px 0'>Desenvolvido por: <b>" + AUTHOR + "</b><br>"
            + "<a href='" + AUTHOR_URL + "'>" + AUTHOR_URL + "</a></p>"
            + "<p style='margin:6px 0'>Repositório:<br><a href='" + REPO_URL + "'>" + REPO_URL + "</a></p>"
            + "<p style='margin:6px 0'>MediaMTX:<br><a href='" + MEDIAMTX_URL + "'>" + MEDIAMTX_URL + "</a></p>"
            + "<hr><small>Licença MIT &bull; " + AUTHOR + " &copy; 2026</small>"
            + "</body></html>";
        JEditorPane pane = new JEditorPane("text/html", html);
        pane.setEditable(false);
        pane.setOpaque(false);
        pane.addHyperlinkListener(ev -> {
            if (ev.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED)
                openBrowser(ev.getURL().toString());
        });
        JOptionPane.showMessageDialog(this, pane, "Sobre o MediaMTX GUI", JOptionPane.PLAIN_MESSAGE);
    }

    private JMenu menu(String name) {
        JMenu m = new JMenu(name);
        m.setFont(Theme.FONT_MEDIUM);
        return m;
    }

    private JMenuItem item(String name, ActionListener al) {
        JMenuItem i = new JMenuItem(name);
        i.setFont(Theme.FONT_SMALL);
        i.addActionListener(al);
        return i;
    }

    public static void openBrowser(String url) {
        try { Desktop.getDesktop().browse(new java.net.URI(url)); }
        catch (Exception ignored) {}
    }

    public LogPanel    getLogPanel()    { return logPanel; }
    public ConfigPanel getConfigPanel() { return configPanel; }  // ← NOVO getter
}